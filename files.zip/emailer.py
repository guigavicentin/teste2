"""
emailer.py
-----------
Envio do relatório PDF por e-mail. Usa `email.message.EmailMessage` (não
concatenação manual de strings), que já sanitiza e codifica cabeçalhos
corretamente — evita injeção de cabeçalho de e-mail (CRLF injection) por
construção, mesmo se algum campo escapasse da validação de entrada.

Credenciais SMTP vêm de variáveis de ambiente — nunca hardcoded.
"""

import os
import smtplib
from email.message import EmailMessage

SMTP_HOST = os.environ.get("SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
SMTP_FROM = os.environ.get("SMTP_FROM", SMTP_USER)


def send_report_email(*, to_email: str, name: str, domain: str, score: int, pdf_bytes: bytes) -> bool:
    if not SMTP_HOST or not SMTP_USER or not SMTP_PASSWORD:
        raise RuntimeError(
            "SMTP não configurado. Defina SMTP_HOST, SMTP_USER, SMTP_PASSWORD, "
            "SMTP_PORT e SMTP_FROM como variáveis de ambiente."
        )

    msg = EmailMessage()
    msg["Subject"] = "Seu relatório de análise de segurança — WS Vicentin"
    msg["From"] = SMTP_FROM
    msg["To"] = to_email  # EmailMessage valida/normaliza o endereço internamente

    msg.set_content(
        f"Olá {name.strip()[:80]},\n\n"
        f"Segue em anexo o relatório detalhado da análise do domínio {domain}.\n"
        f"Nota geral: {score}/100.\n\n"
        "Se quiser aprofundar a análise (pentest completo) ou falar sobre "
        "monitoramento de vazamento de credenciais (leaks), é só responder "
        "este e-mail ou chamar no WhatsApp: https://wa.me/5547992070823\n\n"
        "— WS Vicentin, Segurança Ofensiva"
    )

    msg.add_attachment(
        pdf_bytes, maintype="application", subtype="pdf",
        filename=f"relatorio-seguranca-{domain}.pdf",
    )

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)

    return True
