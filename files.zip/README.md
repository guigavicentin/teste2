# Radar de Segurança — Backend (WS Vicentin)

Backend Python real, já conectado ao `index.html` (sem simulação) — todas
as análises abaixo são de verdade, passivas ou equivalentes a uma
navegação HTTP comum, sem varredura de portas fora da lista fixa.

## O que ele analisa de fato

| Categoria | Como | Fonte |
|---|---|---|
| Subdomínios | Certificate Transparency logs | crt.sh (público) |
| DNS | Resolução A/CNAME | consulta DNS padrão |
| Headers de segurança | HSTS, CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy | requisição HTTP GET normal |
| CDN | Assinaturas de header (Cloudflare, Akamai, Fastly, CloudFront, Sucuri, Incapsula) | requisição HTTP GET normal |
| WAF | Assinatura de header + 1 requisição de sondagem benigna (payload inofensivo, sem exploração) | técnica usada por ferramentas públicas como wafw00f |
| HTTPS forçado | Verifica se HTTP redireciona para HTTPS | requisição HTTP GET normal |
| Spoofing de e-mail (SPF/DMARC/DKIM) | Leitura de registros TXT do DNS (raiz, `_dmarc.`, seletores DKIM comuns) | consulta DNS pública |
| Portas comuns + banner | Conexão TCP direta em 80/21/22/5432/3306/8080 e leitura do banner que o serviço envia | mesma técnica de Shodan/Censys/SecurityScorecard/BitSight |
| Fingerprint de tecnologia | CMS (WordPress/Joomla/Drupal/Magento/Shopify/PrestaShop), bibliotecas JS (jQuery/React/Vue/Angular), vazamento de versão em `Server`/`X-Powered-By` | reaproveita o HTML/headers já obtidos na checagem de headers — **zero requisição extra** |
| Certificado TLS | Validade (dias até expirar) e protocolo negociado (TLS 1.2/1.3 vs. 1.0/1.1) | handshake TLS padrão, igual a abrir `https://` no navegador |
| Arquivos sensíveis expostos | GET numa lista curta e fixa (`.git/config`, `.env`, `.aws/credentials`, `backup.zip`, etc.) | equivalente a digitar a URL no navegador |

### Por que não usei o WhatWeb de verdade

O WhatWeb (Ruby) tem plugins que fazem varredura recursiva de paths e
comportamento mais agressivo do que o necessário aqui, além de não
estar disponível no set de dependências Python do projeto. Reimplementei
o essencial (fingerprint de CMS/JS libs via HTML/headers) em Python
puro, sob controle direto — sem requisições extras além das que já
fazíamos para os headers de segurança.

## Sobre a varredura de portas (80/21/22/5432/3306/8080)

Implementei como pedido, mas com uma arquitetura específica pensada
para reduzir o risco:

- **Lista fixa e curta** de portas — não é um range completo
  (1–65535), o que reduziria ainda mais a semelhança com um scan de
  reconhecimento agressivo.
- **Uma única tentativa de conexão por porta**, sem retry, sem
  autenticação, sem payload em bancos/SSH/FTP — só conecta e lê o que o
  próprio serviço manda de cara (é basicamente o que acontece se você
  digitar o IP:porta num terminal com `nc` ou `telnet`).
- Essa técnica é essencialmente a mesma usada por serviços de "attack
  surface rating" que já operam publicamente há anos (Shodan, Censys,
  SecurityScorecard, BitSight, UpGuard) — eles escaneiam portas comuns
  de IPs públicos continuamente, sem pedir autorização individual a
  cada empresa.
- **Mesmo assim, o banner/versão captado (ex: "OpenSSH 7.4", "MySQL
  5.7") NUNCA vai para o payload `public`.** Isso fica só em `full`
  (uso interno), porque é justamente o tipo de dado que vira ponto de
  partida para procurar CVE de uma versão específica. Na tela do lead,
  ele só vê "Exposição de Serviços de Rede: Crítico/Atenção/Adequado" —
  sem saber qual porta, qual serviço, qual versão.
- **21, 22, 3306 e 5432 abertos publicamente já derrubam a nota** dessa
  categoria (`RISKY_PORTS` no código) — a lógica de negócio que você
  pediu ("avisar que não é legal ter essas portas abertas") está
  aplicada em `port_exposure_score()`.

Se no futuro você quiser ir além dessas 6 portas, meu conselho
continua o mesmo de antes: para range completo de portas, vale a pena
condicionar isso à verificação de propriedade do domínio (TXT record),
não só ao e-mail corporativo.

## O que **não** está incluído (de propósito)

- **Qualquer exploração** (SQLi, XSS de verdade, brute-force contra os
  serviços encontrados em 21/22/3306/5432, etc). O scan é só
  reconhecimento — tentar autenticar ou explorar já é outra categoria
  jurídica.

## Como rodar

```bash
pip install -r requirements.txt
python app.py
# API sobe em http://localhost:5000
```

Teste rápido:
```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"name":"Teste","email":"voce@suaempresa.com.br","domain":"suaempresa.com.br"}'
```

## Como conectar ao front-end (`index.html`)

✅ **Já está feito** — o `index.html` atual não usa mais `runDemoAnalysis`.
O formulário chama de verdade:

```js
fetch(`${API_BASE_URL}/api/analyze`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name, email, domain }), // sem phone — campo removido
});
```

E consome a resposta real da API (`data.display_score`, `data.risk_label`,
`data.categories`) em vez de qualquer simulação. O único ajuste que
**você** ainda precisa fazer é trocar o placeholder no topo do `<script>`
do `index.html`:

```js
const API_BASE_URL = "https://SEU-BACKEND-AQUI.com.br"; // <- aponte pro seu servidor Flask
```

Pela URL onde o `app.py` estiver rodando. Fora isso, a integração já
está pronta e testada (ver seção "Novo fluxo" abaixo).

## ⚠️ O ponto mais importante desta arquitetura

O endpoint `/api/analyze` **só retorna o nível `public`** — nota geral e
categorias por nome, nunca "qual header falta em qual subdomínio" nem
"qual WAF foi contornado". Isso é proposital e **precisa continuar
assim**: se um dia você quiser mostrar mais detalhe, faça isso only
depois de contato comercial e autorização confirmada, e sirva esse
detalhe por um endpoint separado protegido (não pelo mesmo endpoint
público que qualquer visitante do site consegue chamar direto pelo
DevTools).

Ou seja: **não adianta só "esconder" o detalhe no front-end** — se a API
retornar tudo e o JavaScript só não mostrar na tela, qualquer pessoa
com F12 aberto vê a resposta de rede completa. A filtragem tem que
acontecer no servidor, como já está feita aqui.

## Novo fluxo (nota 0-10 + PDF por e-mail)

- Formulário público pede só **Nome, E-mail corporativo, Domínio** (telefone foi removido).
- A tela mostra uma **nota de 0 a 10** (10 = nenhuma camada de segurança
  aplicada, 0 = análise inicial não apontou nada — escala invertida,
  conforme pedido), o rótulo de risco, e o estado (Crítico/Atenção/
  Adequado) de cada categoria — sem número exato nem detalhe técnico.
- O **PDF completo** (`pdf_report.py`) é gerado e enviado por e-mail
  (`emailer.py`) para o endereço corporativo informado, em uma thread
  separada — o navegador do lead nunca recebe o payload `full`.
- Removida a checagem de arquivos sensíveis (`.git/config`, `.env` etc.)
  a pedido do cliente — ficou só o que é análise pública e simples.

## Camadas de segurança aplicadas no próprio código

| Ameaça | Onde é tratada | Como |
|---|---|---|
| **SSRF** | `netsec.py` | Todo hostname é resolvido e validado (`ipaddress`) antes de qualquer requisição/conexão — rejeita IP privado, loopback, link-local (inclui `169.254.169.254`, metadados de nuvem), multicast e reservado. Redirecionamento HTTP nunca é seguido automaticamente: cada `Location` é revalidado antes de continuar (`safe_get`). |
| **RCE / Command Injection** | todo o backend | Nenhuma chamada a `subprocess`, `os.system` ou `eval` em lugar nenhum do código — não existe superfície para injeção de comando. |
| **LFI / Path Traversal** | `pdf_report.py`, `app.py` | O PDF é gerado inteiramente em memória (`io.BytesIO`) e enviado como anexo — nunca é escrito em disco com nome derivado de input do usuário. |
| **XSS** | `app.py` (entrada), `analyzer.py::sanitize_text` (saída), `index.html` | Entrada validada por **allowlist** (regex fechada) em nome/e-mail/domínio — allowlist é mais segura que blocklist porque não depende de prever todo caractere perigoso. Saída para PDF sempre passa por `sanitize_text` (escape XML). No front-end, toda inserção de dado dinâmico usa `textContent`, nunca `innerHTML`. |
| **SSTI** | `pdf_report.py` | reportlab interpreta uma mini-marcação tipo XML dentro de `Paragraph` — texto do usuário (nome, domínio) é sempre escapado com `xml.sax.saxutils.escape` antes de entrar em qualquer parágrafo, então não pode injetar marcação/formatação. Não há Jinja2/template dinâmico com conteúdo do usuário como fonte de template em lugar nenhum. |
| **Header Injection (e-mail)** | `emailer.py` | Uso de `email.message.EmailMessage` (não concatenação manual de string) — a biblioteca já sanitiza/codifica cabeçalhos, então CRLF injection não tem como acontecer mesmo se algum campo escapasse da validação. |
| **Abuso / DoS** | `app.py` | `flask-limiter`: 5 análises por hora por IP na rota `/api/analyze` (mais rígido que o limite geral de 30/hora). |

## Sobre o HTML/front-end

- Nenhuma inserção de dado do usuário via `innerHTML` — tudo via
  `textContent`, que o navegador nunca interpreta como HTML/JS.
- Validação client-side é **espelho** da validação do servidor (mesma
  regex), mas lembre-se: **validação client-side nunca é a linha de
  defesa real** — ela só melhora a experiência; a validação que importa
  é a do `app.py`.
- Comentário no `<head>` com a sugestão de `Content-Security-Policy` e
  demais headers de segurança — precisam ser configurados no
  servidor/CDN que for servir o arquivo (não dá pra forçar
  `Strict-Transport-Security` nem `X-Frame-Options` via `<meta>`).
- E-mail do lead é mascarado na tela (`jo***@empresa.com.br`) em vez de
  reexibido por completo, por minimização de dado exposto na UI.

## Coisas para revisar antes de produção

0. **Variáveis de ambiente obrigatórias** — defina antes de rodar:
   `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`.
   Sem isso, `/api/analyze` roda a análise mas falha ao enviar o PDF
   (o erro fica só no log do servidor, o lead não vê stack trace).

1. **Rate limiting** — hoje qualquer um pode chamar o endpoint repetidamente.
   Adicione um limitador (ex: `flask-limiter`) por IP/e-mail.
2. **CORS** — troque `CORS(app)` por `CORS(app, origins=["https://seudominio.com.br"])`.
3. **Persistência do lead** — hoje o lead só é logado (`log.info`). Ligue
   isso a um banco/CRM real (o `TODO` está marcado no `app.py`).
4. **LGPD** — como discutido antes, você vai armazenar e-mail corporativo,
   telefone e dados de infraestrutura de terceiros. Vale política de
   privacidade e base legal de tratamento documentadas antes de ir ao ar.
5. **Timeouts** — domínios muito grandes com muitos subdomínios podem
   deixar a análise lenta; considere rodar isso em fila assíncrona
   (Celery/RQ) e devolver o resultado por polling ou webhook, em vez de
   segurar a requisição HTTP até terminar.
