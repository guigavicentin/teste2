"""
pdf_report.py
--------------
Gera o PDF detalhado que vai por e-mail para o endereço corporativo
verificado (nunca é servido diretamente para o navegador do lead).

Nota de segurança importante: o reportlab interpreta uma mini-marcação
tipo XML dentro de `Paragraph` (ex.: <b>, <font color=...>). Se o texto
de entrada (nome da pessoa, domínio) fosse inserido sem escapar, alguém
poderia injetar essa marcação — uma forma de "SSTI" dentro do próprio
motor de PDF. Por isso TODO texto vindo do usuário passa por
`analyzer.sanitize_text()` (que usa `xml.sax.saxutils.escape`) antes de
entrar em qualquer Paragraph.
"""

import io
import os

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_LEFT

from analyzer import sanitize_text

GREEN = colors.HexColor("#1f9a53")
RED = colors.HexColor("#c0293b")
AMBER = colors.HexColor("#b8790a")
DARK = colors.HexColor("#111417")
MUTED = colors.HexColor("#5a655f")


def _state_color(state: str):
    return {"Crítico": RED, "Atenção": AMBER, "Adequado": GREEN}.get(state, MUTED)


def build_pdf_report(*, name: str, domain: str, report: dict) -> bytes:
    """report = payload nível 'full' vindo de analyzer.run_analysis().
    Retorna os bytes do PDF (para anexar no e-mail)."""

    safe_name = sanitize_text(name, max_len=80)
    safe_domain = sanitize_text(domain, max_len=253)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2 * cm, rightMargin=2 * cm,
        title=f"Relatorio de Seguranca - {safe_domain}",
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleWSV", parent=styles["Title"], textColor=DARK, fontSize=20)
    h2 = ParagraphStyle("H2WSV", parent=styles["Heading2"], textColor=DARK, spaceBefore=14, spaceAfter=6)
    body = ParagraphStyle("BodyWSV", parent=styles["BodyText"], textColor=DARK, alignment=TA_LEFT, fontSize=10, leading=14)
    small = ParagraphStyle("SmallWSV", parent=styles["BodyText"], textColor=MUTED, fontSize=8, leading=11)

    elements = []
    elements.append(Paragraph("WS Vicentin — Relatório de Superfície de Ataque", title_style))
    elements.append(Spacer(1, 4))
    elements.append(Paragraph(f"Domínio analisado: <b>{safe_domain}</b>", body))
    elements.append(Paragraph(f"Solicitado por: {safe_name}", body))
    elements.append(Spacer(1, 10))

    score = report.get("score", 0)
    risk = sanitize_text(report.get("risk_label", ""), max_len=40)
    elements.append(Paragraph(f"Nota geral de proteção: <b>{score}/100</b> — {risk}", h2))

    # tabela de categorias
    cat_rows = [["Categoria", "Nota", "Situação"]]
    for c in report.get("categories", []):
        cat_rows.append([
            sanitize_text(c["name"], max_len=60),
            str(c["val"]),
            sanitize_text(c["state"], max_len=20),
        ])
    cat_table = Table(cat_rows, colWidths=[9 * cm, 2.5 * cm, 4 * cm])
    cat_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b0f12")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f6f8f7")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(cat_table)
    elements.append(Spacer(1, 16))

    # detalhe técnico — subdomínios
    elements.append(Paragraph("Subdomínios analisados", h2))
    sub_rows = [["Subdomínio", "Headers", "WAF", "CDN", "HTTPS forçado", "Risco"]]
    for s in report.get("subdomains", []):
        if not s.get("reachable"):
            continue
        sub_rows.append([
            sanitize_text(s["subdomain"], max_len=60),
            f"{s['headers']['score']}%",
            "Sim" if s["waf"]["detected"] else "Não",
            sanitize_text(s["cdn"] or "—", max_len=20),
            "Sim" if s["https_redirect"] else "Não",
            sanitize_text(s["risk"], max_len=15),
        ])
    if len(sub_rows) > 1:
        sub_table = Table(sub_rows, colWidths=[5 * cm, 2 * cm, 2 * cm, 2.5 * cm, 2.7 * cm, 1.8 * cm])
        sub_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b0f12")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f6f8f7")]),
        ]))
        elements.append(sub_table)
    else:
        elements.append(Paragraph("Nenhum subdomínio respondeu durante a análise.", body))

    # headers ausentes (detalhe técnico completo, só aqui no PDF interno)
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("Headers de segurança ausentes por subdomínio", h2))
    for s in report.get("subdomains", []):
        if s.get("reachable") and s["headers"]["missing"]:
            missing = ", ".join(sanitize_text(h, 40) for h in s["headers"]["missing"])
            elements.append(Paragraph(f"<b>{sanitize_text(s['subdomain'], 60)}</b>: faltando {missing}", body))

    # portas de risco
    risky = report.get("risky_ports_open", [])
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("Portas sensíveis expostas publicamente", h2))
    if risky:
        for p in risky:
            banner = sanitize_text(p.get("banner") or "sem banner identificado", 100)
            elements.append(Paragraph(f"Porta <b>{p['port']}</b> ({sanitize_text(p['service'], 30)}) — {banner}", body))
    else:
        elements.append(Paragraph("Nenhuma porta sensível (21/22/3306/5432) encontrada aberta.", body))

    # spoofing
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("Proteção contra spoofing de e-mail", h2))
    spoof = report.get("email_spoofing", {})
    elements.append(Paragraph(f"SPF: {'presente' if spoof.get('spf', {}).get('present') else 'ausente'}", body))
    dmarc = spoof.get("dmarc", {})
    dmarc_txt = "ausente"
    if dmarc.get("present"):
        dmarc_txt = f"presente (política: {sanitize_text(dmarc.get('policy') or 'não especificada', 20)})"
    elements.append(Paragraph(f"DMARC: {dmarc_txt}", body))
    elements.append(Paragraph(f"DKIM: {'presente' if spoof.get('dkim', {}).get('present') else 'não identificado (seletor comum)'}", body))

    # TLS
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("Certificado TLS", h2))
    tls_info = report.get("tls_info", {})
    if tls_info.get("checked"):
        elements.append(Paragraph(f"Protocolo negociado: {sanitize_text(tls_info.get('protocol') or '—', 20)}", body))
        elements.append(Paragraph(f"Emissor: {sanitize_text(tls_info.get('issuer') or '—', 60)}", body))
        elements.append(Paragraph(f"Dias até expirar: {tls_info.get('days_to_expiry', '—')}", body))
    else:
        elements.append(Paragraph("Não foi possível validar o certificado TLS.", body))

    # DNS / blocklist
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("Maturidade de DNS e reputação", h2))
    hardening = report.get("dns_hardening", {})
    elements.append(Paragraph(f"DNSSEC: {'ativo' if hardening.get('dnssec') else 'não detectado'}", body))
    elements.append(Paragraph(f"CAA: {'configurado' if hardening.get('caa') else 'não configurado'}", body))
    elements.append(Paragraph(f"security.txt: {'presente' if report.get('security_txt') else 'ausente'}", body))
    rep = report.get("blocklist_reputation", {})
    listed = rep.get("ip_listed") or rep.get("domain_listed")
    elements.append(Paragraph(f"Presença em blocklist (Spamhaus): {'SIM — requer atenção' if listed else 'não listado'}", body))

    elements.append(Spacer(1, 20))
    elements.append(Paragraph(
        "Este relatório reflete uma análise automatizada de reconhecimento passivo, "
        "realizada em " + sanitize_text(str(report.get("generated_at", "")), 30) +
        ". Para uma avaliação aprofundada (incluindo testes manuais de exploração), "
        "fale com nosso time para orçamento de Pentest Web.", small,
    ))

    doc.build(elements)
    return buffer.getvalue()
