"""
netsec.py
----------
Camada de proteção contra SSRF (Server-Side Request Forgery).

O motivo deste arquivo existir separado: TODA função do analyzer.py que
faz uma requisição de rede recebe, em última instância, um domínio
digitado por um visitante público do site. Sem validação, isso permite
um clássico ataque de SSRF: o visitante coloca "meudominio-fake.com"
apontando (via DNS que ELE controla) para "169.254.169.254" (endpoint
de metadados de nuvem AWS/GCP/Azure) ou para "127.0.0.1"/"10.0.0.5"
(serviços internos da própria infraestrutura que roda este backend), e
nosso servidor faz a requisição "confiando" que é um domínio normal.

Mitigação aplicada aqui:
1. Resolve o hostname e verifica se TODOS os IPs retornados são
   públicos (não privados, loopback, link-local, multicast, reservados).
2. Requisições HTTP são feitas SEM seguir redirecionamento automático;
   cada "Location" de redirect é resolvido e revalidado antes de seguir
   (evita que um domínio público redirecione para um IP interno).
3. Limite de redirecionamentos seguidos (evita loop/túnel de redirects).
4. Timeout curto em toda operação de rede.

Isso não elimina 100% o risco de DNS rebinding (reresolver o mesmo
hostname para outro IP entre a validação e a conexão real), mas reduz
drasticamente a superfície — e é o padrão adotado por scanners de
superfície de ataque comerciais.
"""

import ipaddress
import socket
from urllib.parse import urlparse, urljoin

import requests

CONNECT_TIMEOUT = 6
MAX_REDIRECTS = 3


class SSRFBlocked(Exception):
    """Levantada quando um alvo resolve para um IP não público."""


def is_public_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return not (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    )


def resolve_public_ips(hostname: str) -> list:
    """Resolve o hostname e retorna só IPs públicos. Levanta SSRFBlocked
    se NENHUM IP resolvido for público (protege contra domínio apontando
    para rede interna)."""
    try:
        infos = socket.getaddrinfo(hostname, None)
        all_ips = sorted({info[4][0] for info in infos})
    except Exception as exc:
        raise SSRFBlocked(f"não foi possível resolver {hostname}: {exc}")

    public_ips = [ip for ip in all_ips if is_public_ip(ip)]
    if not public_ips:
        raise SSRFBlocked(f"{hostname} resolve apenas para IP privado/reservado — bloqueado")
    return public_ips


def assert_public_host(hostname: str) -> None:
    """Só valida, sem retornar nada — usado antes de socket.connect direto
    (ex.: varredura de portas) onde já temos o IP resolvido em outro lugar."""
    resolve_public_ips(hostname)


def safe_get(url: str, timeout: int = CONNECT_TIMEOUT, headers: dict | None = None):
    """GET com proteção SSRF: valida IP antes de cada hop e não segue
    redirecionamento automaticamente."""
    headers = headers or {}
    current_url = url
    for _ in range(MAX_REDIRECTS + 1):
        parsed = urlparse(current_url)
        if parsed.scheme not in ("http", "https"):
            raise SSRFBlocked(f"esquema não permitido: {parsed.scheme}")
        if not parsed.hostname:
            raise SSRFBlocked("URL sem host válido")

        resolve_public_ips(parsed.hostname)  # levanta SSRFBlocked se privado

        resp = requests.get(
            current_url, timeout=timeout, allow_redirects=False,
            headers=headers, verify=True,
        )
        if resp.is_redirect or resp.status_code in (301, 302, 303, 307, 308):
            location = resp.headers.get("Location")
            if not location:
                return resp
            current_url = urljoin(current_url, location)
            continue
        return resp

    raise SSRFBlocked("excesso de redirecionamentos")
