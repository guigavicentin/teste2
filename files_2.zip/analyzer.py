"""
analyzer.py
------------
Motor de análise de superfície de ataque.

Toda requisição HTTP/conexão TCP passa por netsec.py, que bloqueia
alvos que resolvam para IP privado/reservado (proteção SSRF). Nenhuma
função aqui usa subprocess/os.system/eval — zero superfície de Command
Injection ou RCE por design.

Camadas de coleta:

1) PASSIVAS (DNS público ou requisição HTTP equivalente a um visitante comum):
   - enum_subdomains()        -> Certificate Transparency logs (crt.sh)
   - resolve_dns()            -> DNS público
   - fetch_headers()          -> GET HTTP normal (via netsec.safe_get)
   - detect_cdn()             -> leitura de headers de resposta
   - check_https_redirect()   -> segue redirecionamento HTTP->HTTPS
   - check_email_spoofing_protection() -> TXT (SPF/DMARC/DKIM)
   - fingerprint_technology()  -> reaproveita HTML/headers já obtidos
   - check_tls_info()          -> handshake TLS padrão
   - check_dns_hardening()     -> presença de DNSSEC e CAA (registros
     públicos, sinal de maturidade de configuração)
   - check_security_txt()      -> presença de /.well-known/security.txt
     (RFC 9116) — arquivo PÚBLICO por definição, feito para ser lido
     por qualquer pessoa; o oposto de um arquivo sensível.
   - check_blocklist_reputation() -> consulta DNSBL pública (Spamhaus
     ZEN/DBL) — a mesma checagem que qualquer administrador de e-mail
     faz o tempo todo.

2) SONDAGEM LEVE (poucas requisições adicionais benignas, sem exploração):
   - detect_waf()              -> 2 payloads inofensivos (SQLi-like,
     XSS-like), só observa bloqueio.

3) CONEXÃO DIRETA EM PORTAS ESPECÍFICAS + BANNER GRAB:
   - scan_common_ports()       -> 80/21/22/5432/3306/8080, uma tentativa
     cada, sem autenticação.

REMOVIDO NESTA VERSÃO:
   - Checagem de arquivos sensíveis (.git/config, .env, etc.). Mesmo
     sendo tecnicamente "só um GET público", o valor de negócio não
     compensa o risco de reputação de rodar isso publicamente sem
     verificação de autorização mais forte — decisão consciente do
     cliente (WS Vicentin), registrada aqui para histórico.

NÃO incluído (permanece de fora):
   - Rodar WhatWeb real, forçar TLS antigo, autenticar em qualquer
     serviço encontrado, ou qualquer path fora do necessário.
"""

import re
import socket
import ssl
import time
import concurrent.futures
from datetime import datetime, timezone
from xml.sax.saxutils import escape as xml_escape

import requests
import dns.resolver

from netsec import safe_get, resolve_public_ips, is_public_ip, SSRFBlocked

REQUEST_TIMEOUT = 6
PORT_TIMEOUT = 2.5
MAX_SUBDOMAINS = 25

# lista curta de nomes comuns — só gera consultas DNS (leitura pública),
# não toca no host de forma nenhuma; complementa o que os logs de
# Certificate Transparency não cobrem (ex.: painéis internos sem
# certificado próprio, ou emitido só internamente)
COMMON_SUBDOMAIN_WORDLIST = [
    "www", "mail", "webmail", "smtp", "pop", "imap", "ftp", "sftp",
    "vpn", "remote", "api", "dev", "staging", "homolog", "test",
    "admin", "portal", "painel", "app", "blog", "shop", "loja",
    "suporte", "support", "helpdesk", "cpanel", "whm", "autodiscover",
    "cdn", "static", "assets", "img", "media", "docs", "status",
    "monitor", "git", "gitlab", "ci", "dashboard", "crm", "erp",
    "intranet", "extranet", "old", "new", "beta",
]

USER_AGENT = "WSVicentin-Radar/1.0 (+security-scan; contato: https://wa.me/5547992070823)"

SECURITY_HEADERS = [
    "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
    "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy",
]

CDN_SIGNATURES = {
    "cloudflare": ["cf-ray", "cf-cache-status"],
    "akamai": ["x-akamai-transformed", "akamai-x-cache"],
    "fastly": ["x-served-by", "x-fastly-request-id"],
    "cloudfront": ["x-amz-cf-id", "x-amz-cf-pop"],
    "sucuri": ["x-sucuri-id", "x-sucuri-cache"],
    "incapsula": ["x-iinfo", "x-cdn"],
}

WAF_HEADER_SIGNATURES = {
    "Cloudflare": ["cf-ray"], "Sucuri": ["x-sucuri-id"], "Incapsula/Imperva": ["x-iinfo"],
    "AWS WAF": ["x-amzn-requestid", "x-amzn-waf-action"], "Akamai": ["akamai-x-cache"],
}

WAF_PROBES = [
    "?q=%27%20OR%20%271%27%3D%271",
    "?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E",
]

PORT_MAP = {80: "HTTP", 21: "FTP", 22: "SSH", 5432: "PostgreSQL", 3306: "MySQL", 8080: "HTTP-Alt"}
RISKY_PORTS = {21, 22, 3306, 5432}

COMMON_DKIM_SELECTORS = ["google", "default", "selector1", "selector2", "k1", "mail", "dkim", "s1", "s2"]

TECH_SIGNATURES = {
    "WordPress": ["wp-content", "wp-includes", "wp-json", "wordpress"],
    "Joomla": ["/media/jui/", "joomla!", "joomla"],
    "Drupal": ["drupal.settings", "sites/default/files", "drupal"],
    "Magento": ["mage.cookies", "skin/frontend", "magento"],
    "Shopify": ["cdn.shopify.com", "shopify"],
    "PrestaShop": ["prestashop"],
}

JS_LIB_SIGNATURES = {
    "jQuery": ["jquery"], "React": ["data-reactroot", "react-dom"],
    "Vue.js": ["__vue__", "vue.js", "vue.min.js"], "Angular": ["ng-version", "angular.js"],
}


def sanitize_text(value: str, max_len: int = 120) -> str:
    """Usado para textos que vão para PDF/e-mail (reportlab interpreta
    um mini-XML nos Paragraphs — sem isso, um nome como
    '<font color=red>x</font>' seria interpretado como marcação, uma
    forma de SSTI/HTML-injection dentro do próprio motor de PDF)."""
    return xml_escape((value or "").strip()[:max_len])


def normalize_domain(raw: str) -> str:
    raw = raw.strip().lower()
    raw = re.sub(r"^https?://", "", raw)
    raw = re.sub(r"^www\.", "", raw)
    raw = raw.split("/")[0]
    return raw


def is_valid_domain(domain: str) -> bool:
    return bool(re.match(r"^([a-z0-9-]+\.)+[a-z]{2,}$", domain)) and len(domain) <= 253


def _enum_crtsh(domain: str) -> set:
    subs = set()
    try:
        resp = requests.get(
            f"https://crt.sh/?q=%25.{domain}&output=json",
            timeout=10, headers={"User-Agent": USER_AGENT},
        )
        if resp.ok:
            for entry in resp.json():
                for name in entry.get("name_value", "").split("\n"):
                    name = name.strip().lower()
                    if name.endswith(domain) and "*" not in name and is_valid_domain(name):
                        subs.add(name)
    except Exception:
        pass
    return subs


def _enum_certspotter(domain: str) -> set:
    """CertSpotter — outro agregador público de Certificate Transparency,
    cobertura de logs parcialmente diferente do crt.sh (complementar,
    não redundante)."""
    subs = set()
    try:
        resp = requests.get(
            f"https://api.certspotter.com/v1/issuances?domain={domain}"
            f"&include_subdomains=true&expand=dns_names",
            timeout=10, headers={"User-Agent": USER_AGENT},
        )
        if resp.ok:
            for entry in resp.json():
                for name in entry.get("dns_names", []):
                    name = name.strip().lower()
                    if name.endswith(domain) and "*" not in name and is_valid_domain(name):
                        subs.add(name)
    except Exception:
        pass
    return subs


def _enum_hackertarget(domain: str) -> set:
    """HackerTarget hostsearch — API pública gratuita (com rate limit),
    agrega fontes próprias de reconhecimento passivo de subdomínio."""
    subs = set()
    try:
        resp = requests.get(
            f"https://api.hackertarget.com/hostsearch/?q={domain}",
            timeout=10, headers={"User-Agent": USER_AGENT},
        )
        if resp.ok and "error" not in resp.text[:80].lower() and "api count exceeded" not in resp.text[:80].lower():
            for line in resp.text.splitlines():
                name = line.split(",")[0].strip().lower()
                if name.endswith(domain) and is_valid_domain(name):
                    subs.add(name)
    except Exception:
        pass
    return subs


def _enum_bruteforce(domain: str) -> set:
    """Só resolve DNS pros nomes comuns — nenhuma requisição HTTP, nenhum
    dado enviado ao host, é o mesmo tipo de consulta que qualquer
    resolvedor DNS público processa o tempo todo."""
    found = set()

    def check(word):
        fqdn = f"{word}.{domain}"
        info = resolve_dns(fqdn)
        return fqdn if info["resolved"] else None

    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        for result in executor.map(check, COMMON_SUBDOMAIN_WORDLIST):
            if result:
                found.add(result)
    return found


def enum_subdomains(domain: str, limit: int = MAX_SUBDOMAINS):
    subs = {domain, f"www.{domain}"}
    subs |= _enum_crtsh(domain)
    subs |= _enum_certspotter(domain)
    subs |= _enum_hackertarget(domain)
    subs |= _enum_bruteforce(domain)
    return sorted(subs)[:limit]


def resolve_dns(hostname: str):
    result = {"resolved": False, "ips": [], "cname": None}
    try:
        answers = dns.resolver.resolve(hostname, "A", lifetime=5)
        result["ips"] = sorted({r.address for r in answers})
        result["resolved"] = True
    except Exception:
        try:
            result["ips"] = [socket.gethostbyname(hostname)]
            result["resolved"] = True
        except Exception:
            pass
    try:
        cname_answers = dns.resolver.resolve(hostname, "CNAME", lifetime=5)
        if cname_answers:
            result["cname"] = str(cname_answers[0].target).rstrip(".")
    except Exception:
        pass
    return result


def fetch(url: str, timeout=REQUEST_TIMEOUT):
    """Wrapper único de GET — sempre passa pela validação SSRF."""
    return safe_get(url, timeout=timeout, headers={"User-Agent": USER_AGENT})


def analyze_security_headers(headers) -> dict:
    lower_headers = {k.lower(): v for k, v in headers.items()}
    present = [h for h in SECURITY_HEADERS if h.lower() in lower_headers]
    missing = [h for h in SECURITY_HEADERS if h.lower() not in lower_headers]
    return {"present": present, "missing": missing,
            "score": round(100 * len(present) / len(SECURITY_HEADERS))}


def detect_cdn(headers):
    lower_headers = {k.lower() for k in headers.keys()}
    for cdn_name, sigs in CDN_SIGNATURES.items():
        if any(sig in lower_headers for sig in sigs):
            return cdn_name
    server = headers.get("Server", "").lower()
    for cdn_name in CDN_SIGNATURES:
        if cdn_name in server:
            return cdn_name
    return None


def detect_waf(base_url: str, baseline_headers) -> dict:
    lower_headers = {k.lower() for k in baseline_headers.keys()}
    for waf_name, sigs in WAF_HEADER_SIGNATURES.items():
        if any(sig in lower_headers for sig in sigs):
            return {"detected": True, "name": waf_name, "method": "header"}
    try:
        baseline = fetch(base_url, timeout=5)
        if baseline.status_code != 200:
            return {"detected": False, "name": None, "method": None}
        blocked = 0
        for probe in WAF_PROBES:
            try:
                resp = fetch(base_url + probe, timeout=5)
                if resp.status_code in (403, 406, 419, 429):
                    blocked += 1
            except SSRFBlocked:
                raise
            except Exception:
                continue
        if blocked > 0:
            confidence = "alta" if blocked == len(WAF_PROBES) else "média"
            return {"detected": True, "name": f"Genérico (confiança {confidence})", "method": "probe"}
    except SSRFBlocked:
        raise
    except Exception:
        pass
    return {"detected": False, "name": None, "method": None}


def check_https_redirect(domain: str) -> bool:
    try:
        resp = fetch(f"http://{domain}", timeout=5)
        return resp.url.startswith("https://") if hasattr(resp, "url") else False
    except SSRFBlocked:
        raise
    except Exception:
        return False


# ---------------------------------------------------------------------
# E-mail spoofing: SPF / DMARC / DKIM
# ---------------------------------------------------------------------

def _txt_records(name: str):
    try:
        answers = dns.resolver.resolve(name, "TXT", lifetime=5)
        return [b"".join(r.strings).decode("utf-8", "ignore") for r in answers]
    except Exception:
        return []


def check_email_spoofing_protection(domain: str) -> dict:
    result = {"spf": {"present": False, "raw": None},
              "dmarc": {"present": False, "policy": None, "subdomain_policy": None, "raw": None},
              "dkim": {"present": False, "selector": None}}

    for txt in _txt_records(domain):
        if txt.lower().startswith("v=spf1"):
            result["spf"] = {"present": True, "raw": txt}
            break

    for txt in _txt_records(f"_dmarc.{domain}"):
        if txt.lower().startswith("v=dmarc1"):
            m = re.search(r"(?<![a-z])p=([a-zA-Z]+)", txt, re.IGNORECASE)
            m_sp = re.search(r"sp=([a-zA-Z]+)", txt, re.IGNORECASE)
            policy = m.group(1).lower() if m else None
            # sem tag sp=, subdomínios herdam a mesma política de p=
            # (comportamento padrão definido na RFC 7489)
            subdomain_policy = m_sp.group(1).lower() if m_sp else policy
            result["dmarc"] = {
                "present": True, "policy": policy,
                "subdomain_policy": subdomain_policy, "raw": txt,
            }
            break

    for selector in COMMON_DKIM_SELECTORS:
        if _txt_records(f"{selector}._domainkey.{domain}"):
            result["dkim"] = {"present": True, "selector": selector}
            break

    return result


def spoofing_score(spoof: dict) -> int:
    score = 0
    if spoof["spf"]["present"]:
        score += 40
    if spoof["dmarc"]["present"]:
        score += 40
        if spoof["dmarc"]["policy"] in ("quarantine", "reject"):
            score += 10
    if spoof["dkim"]["present"]:
        score += 10
    return min(score, 100)


# ---------------------------------------------------------------------
# DNS hardening: DNSSEC + CAA (sinais públicos de maturidade)
# ---------------------------------------------------------------------

def check_dns_hardening(domain: str) -> dict:
    result = {"dnssec": False, "caa": False}
    try:
        answers = dns.resolver.resolve(domain, "DNSKEY", lifetime=5)
        result["dnssec"] = len(answers) > 0
    except Exception:
        pass
    try:
        answers = dns.resolver.resolve(domain, "CAA", lifetime=5)
        result["caa"] = len(answers) > 0
    except Exception:
        pass
    return result


def check_security_txt(domain: str) -> bool:
    """/.well-known/security.txt é um arquivo PÚBLICO por definição
    (RFC 9116) — feito para ser lido por qualquer pessoa que queira
    reportar uma vulnerabilidade. Presença é sinal positivo."""
    for scheme in ("https", "http"):
        try:
            resp = fetch(f"{scheme}://{domain}/.well-known/security.txt", timeout=4)
            if resp.status_code == 200 and b"contact" in resp.content.lower():
                return True
        except SSRFBlocked:
            raise
        except Exception:
            continue
    return False


def dns_maturity_score(hardening: dict, has_security_txt: bool) -> int:
    score = 0
    if hardening.get("dnssec"):
        score += 45
    if hardening.get("caa"):
        score += 35
    if has_security_txt:
        score += 20
    return min(score, 100)


# ---------------------------------------------------------------------
# Reputação em blocklists públicas (Spamhaus DNSBL)
# ---------------------------------------------------------------------

def check_blocklist_reputation(domain: str, ip: str | None) -> dict:
    result = {"ip_listed": False, "domain_listed": False}
    try:
        if ip:
            reversed_ip = ".".join(reversed(ip.split(".")))
            try:
                dns.resolver.resolve(f"{reversed_ip}.zen.spamhaus.org", "A", lifetime=4)
                result["ip_listed"] = True
            except dns.resolver.NXDOMAIN:
                pass
            except Exception:
                pass
        try:
            dns.resolver.resolve(f"{domain}.dbl.spamhaus.org", "A", lifetime=4)
            result["domain_listed"] = True
        except dns.resolver.NXDOMAIN:
            pass
        except Exception:
            pass
    except Exception:
        pass
    return result


def blocklist_score(reputation: dict) -> int:
    score = 100
    if reputation.get("ip_listed"):
        score -= 60
    if reputation.get("domain_listed"):
        score -= 60
    return max(0, score)


# ---------------------------------------------------------------------
# Fingerprint de tecnologia
# ---------------------------------------------------------------------

def fingerprint_technology(headers, html: str) -> dict:
    html_lower = (html or "").lower()
    result = {"cms": None, "js_libs": [], "server": headers.get("Server"),
              "powered_by": headers.get("X-Powered-By")}
    for name, sigs in TECH_SIGNATURES.items():
        if any(sig in html_lower for sig in sigs):
            result["cms"] = name
            break
    for name, sigs in JS_LIB_SIGNATURES.items():
        if any(sig in html_lower for sig in sigs):
            result["js_libs"].append(name)
    return result


def version_disclosure_score(fingerprint: dict) -> int:
    leaks = 0
    for val in (fingerprint.get("server"), fingerprint.get("powered_by")):
        if val and re.search(r"\d+\.\d+", val):
            leaks += 1
    return max(0, 100 - leaks * 35)


# ---------------------------------------------------------------------
# TLS
# ---------------------------------------------------------------------

def check_tls_info(domain: str) -> dict:
    info = {"checked": False, "protocol": None, "issuer": None, "days_to_expiry": None}
    try:
        resolve_public_ips(domain)  # bloqueia SSRF antes de conectar
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                info["checked"] = True
                info["protocol"] = ssock.version()
                cert = ssock.getpeercert()
                issuer = dict(x[0] for x in cert.get("issuer", []))
                info["issuer"] = issuer.get("organizationName") or issuer.get("commonName")
                not_after = cert.get("notAfter")
                if not_after:
                    expiry = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    info["days_to_expiry"] = (expiry - datetime.now(timezone.utc)).days
    except SSRFBlocked:
        raise
    except Exception:
        pass
    return info


def tls_score(tls_info: dict) -> int:
    if not tls_info.get("checked"):
        return 50
    score = 100
    if tls_info.get("protocol") in ("TLSv1", "TLSv1.1"):
        score -= 40
    days = tls_info.get("days_to_expiry")
    if days is not None:
        if days < 0:
            score -= 60
        elif days < 15:
            score -= 30
        elif days < 30:
            score -= 10
    return max(0, score)


# ---------------------------------------------------------------------
# Portas comuns + banner grab
# ---------------------------------------------------------------------

def _grab_banner(sock) -> str:
    try:
        sock.settimeout(PORT_TIMEOUT)
        data = sock.recv(200)
        return data.decode("utf-8", "ignore").strip().replace("\r", "").replace("\n", " ")
    except Exception:
        return ""


def _probe_port(ip: str, port: int) -> dict:
    entry = {"port": port, "service": PORT_MAP.get(port, "?"), "open": False, "banner": None}
    try:
        with socket.create_connection((ip, port), timeout=PORT_TIMEOUT) as sock:
            entry["open"] = True
            if port in (80, 8080):
                try:
                    sock.sendall(f"HEAD / HTTP/1.1\r\nHost: {ip}\r\nUser-Agent: {USER_AGENT}\r\nConnection: close\r\n\r\n".encode())
                except Exception:
                    pass
                raw = _grab_banner(sock)
                m = re.search(r"Server:\s*([^\r\n]+)", raw, re.IGNORECASE)
                entry["banner"] = m.group(1).strip() if m else (raw[:80] or None)
            else:
                entry["banner"] = _grab_banner(sock) or None
    except Exception:
        entry["open"] = False
    return entry


def scan_common_ports(domain: str) -> dict:
    try:
        public_ips = resolve_public_ips(domain)  # levanta SSRFBlocked se privado
    except SSRFBlocked:
        raise
    ip = public_ips[0]
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(PORT_MAP)) as executor:
        results = list(executor.map(lambda p: _probe_port(ip, p), PORT_MAP.keys()))
    return {"scanned": True, "ip": ip, "ports": results}


def port_exposure_score(port_scan: dict) -> int:
    if not port_scan.get("scanned"):
        return 50
    risky_open = sum(1 for p in port_scan["ports"] if p["open"] and p["port"] in RISKY_PORTS)
    return max(0, 100 - risky_open * 25)


# ---------------------------------------------------------------------
# Análise por subdomínio
# ---------------------------------------------------------------------

def analyze_subdomain(sub: str) -> dict:
    entry = {
        "subdomain": sub, "dns": resolve_dns(sub), "reachable": False, "cdn": None,
        "waf": {"detected": False, "name": None},
        "headers": {"present": [], "missing": SECURITY_HEADERS, "score": 0},
        "https_redirect": False,
        "tech": {"cms": None, "js_libs": [], "server": None, "powered_by": None},
        "version_leak_score": 50, "risk": "Alto", "blocked_ssrf": False,
    }
    if not entry["dns"]["resolved"]:
        return entry

    # valida SSRF antes de qualquer requisição neste subdomínio
    try:
        resolve_public_ips(sub)
    except SSRFBlocked:
        entry["blocked_ssrf"] = True
        return entry

    for scheme in ("https", "http"):
        url = f"{scheme}://{sub}"
        try:
            resp = fetch(url, timeout=REQUEST_TIMEOUT)
            entry["reachable"] = True
            entry["cdn"] = detect_cdn(resp.headers)
            entry["waf"] = detect_waf(url, resp.headers)
            entry["headers"] = analyze_security_headers(resp.headers)
            entry["tech"] = fingerprint_technology(resp.headers, resp.text[:30000])
            entry["version_leak_score"] = version_disclosure_score(entry["tech"])
            break
        except SSRFBlocked:
            entry["blocked_ssrf"] = True
            return entry
        except Exception:
            continue

    try:
        entry["https_redirect"] = check_https_redirect(sub)
    except SSRFBlocked:
        pass

    score = entry["headers"]["score"]
    if entry["waf"]["detected"]:
        score += 20
    if entry["cdn"]:
        score += 10
    entry["risk"] = "Baixo" if score >= 70 else ("Médio" if score >= 40 else "Alto")
    return entry


def compute_overall_score(subdomain_results, spoof_sc, port_sc, techleak_sc, tls_sc, dns_sc, blocklist_sc) -> int:
    reachable = [s for s in subdomain_results if s["reachable"]]
    if not reachable:
        header_avg = waf_ratio = cdn_ratio = https_ratio = 0
    else:
        n = len(reachable)
        header_avg = sum(s["headers"]["score"] for s in reachable) / n
        waf_ratio = sum(1 for s in reachable if s["waf"]["detected"]) / n
        cdn_ratio = sum(1 for s in reachable if s["cdn"]) / n
        https_ratio = sum(1 for s in reachable if s["https_redirect"]) / n

    score = (
        header_avg * 0.16 +
        waf_ratio * 100 * 0.13 +
        cdn_ratio * 100 * 0.06 +
        https_ratio * 100 * 0.07 +
        spoof_sc * 0.12 +
        port_sc * 0.14 +
        techleak_sc * 0.09 +
        tls_sc * 0.13 +
        dns_sc * 0.05 +
        blocklist_sc * 0.05
    )
    return round(score)


def risk_label(score: int) -> str:
    if score < 40:
        return "Alto Risco"
    if score < 70:
        return "Risco Médio"
    return "Risco Controlado"


def score_to_display_10(score_100: int) -> int:
    """Converte a nota interna (0-100, 100=seguro) para a nota exibida
    (0-10, 10=nenhuma camada de segurança aplicada). Função única,
    compartilhada entre app.py (tela) e pdf_report.py (PDF) — assim as
    duas telas NUNCA podem divergir na mesma análise."""
    inverted = 100 - score_100
    return max(0, min(10, round(inverted / 10)))


def build_categories(subdomain_results, spoof_sc, port_sc, techleak_sc, tls_sc, dns_sc, blocklist_sc) -> list:
    reachable = [s for s in subdomain_results if s["reachable"]]
    n = max(len(reachable), 1)

    header_score = round(sum(s["headers"]["score"] for s in reachable) / n) if reachable else 0
    waf_score = round(100 * sum(1 for s in reachable if s["waf"]["detected"]) / n)
    cdn_score = round(100 * sum(1 for s in reachable if s["cdn"]) / n)
    https_score = round(100 * sum(1 for s in reachable if s["https_redirect"]) / n)
    subdomain_exposure_score = max(0, 100 - min(len(subdomain_results), 20) * 4)

    def state(v):
        if v < 40:
            return "Crítico"
        if v < 70:
            return "Atenção"
        return "Adequado"

    return [
        {"name": "Headers de Segurança", "val": header_score, "state": state(header_score)},
        {"name": "Cobertura de WAF", "val": waf_score, "state": state(waf_score)},
        {"name": "Configuração de CDN", "val": cdn_score, "state": state(cdn_score)},
        {"name": "Tráfego Criptografado (HTTPS)", "val": https_score, "state": state(https_score)},
        {"name": "Exposição de Subdomínios", "val": subdomain_exposure_score, "state": state(subdomain_exposure_score)},
        {"name": "Proteção contra Spoofing de E-mail", "val": spoof_sc, "state": state(spoof_sc)},
        {"name": "Exposição de Serviços de Rede", "val": port_sc, "state": state(port_sc)},
        {"name": "Vazamento de Versão de Tecnologia", "val": techleak_sc, "state": state(techleak_sc)},
        {"name": "Certificado TLS", "val": tls_sc, "state": state(tls_sc)},
        {"name": "Maturidade de DNS (DNSSEC/CAA/security.txt)", "val": dns_sc, "state": state(dns_sc)},
        {"name": "Reputação em Blocklists", "val": blocklist_sc, "state": state(blocklist_sc)},
    ]


def run_analysis(domain_raw: str, level: str = "public") -> dict:
    """
    level='public' -> nota + categorias por NOME (sem detalhe explorável).
    level='full'   -> detalhe técnico completo, uso interno (PDF/equipe).
    """
    domain = normalize_domain(domain_raw)
    if not is_valid_domain(domain):
        raise ValueError("domínio inválido")

    # valida SSRF já na entrada — falha rápido e claro se o domínio
    # resolver para rede interna/reservada
    resolve_public_ips(domain)

    subdomains = enum_subdomains(domain)

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        subdomain_results = list(executor.map(analyze_subdomain, subdomains))

    spoof = check_email_spoofing_protection(domain)
    spoof_sc = spoofing_score(spoof)

    port_scan = scan_common_ports(domain)
    port_sc = port_exposure_score(port_scan)

    tls_info = check_tls_info(domain)
    tls_sc = tls_score(tls_info)

    dns_hardening = check_dns_hardening(domain)
    has_sec_txt = check_security_txt(domain)
    dns_sc = dns_maturity_score(dns_hardening, has_sec_txt)

    reputation = check_blocklist_reputation(domain, port_scan.get("ip"))
    blocklist_sc = blocklist_score(reputation)

    reachable = [s for s in subdomain_results if s["reachable"]]
    techleak_sc = round(sum(s["version_leak_score"] for s in reachable) / len(reachable)) if reachable else 50

    score = compute_overall_score(subdomain_results, spoof_sc, port_sc, techleak_sc, tls_sc, dns_sc, blocklist_sc)
    categories = build_categories(subdomain_results, spoof_sc, port_sc, techleak_sc, tls_sc, dns_sc, blocklist_sc)

    from datetime import datetime as _dt, timezone as _tz
    now = _dt.now(_tz.utc)

    public_payload = {
        "domain": domain,
        "score": score,
        "risk_label": risk_label(score),
        "categories": categories,
        "subdomains_scanned": len(subdomain_results),
        "generated_at": int(time.time()),
        "generated_at_human": now.strftime("%d/%m/%Y às %H:%M UTC"),
    }

    if level == "public":
        return public_payload

    full_payload = dict(public_payload)
    full_payload["subdomains"] = subdomain_results
    full_payload["email_spoofing"] = spoof
    full_payload["port_scan"] = port_scan
    full_payload["risky_ports_open"] = [p for p in port_scan.get("ports", []) if p["open"] and p["port"] in RISKY_PORTS]
    full_payload["tls_info"] = tls_info
    full_payload["dns_hardening"] = dns_hardening
    full_payload["security_txt"] = has_sec_txt
    full_payload["blocklist_reputation"] = reputation
    return full_payload
