"""
app.py — API do Radar de Segurança (WS Vicentin)

Fluxo:
  POST /api/analyze  {name, email, domain}
    1. Valida entrada estritamente (regex fechada em cada campo —
       mitigação de XSS/Header Injection na origem).
    2. Confirma e-mail corporativo (provedor gratuito é rejeitado).
    3. Roda a análise (analyzer.run_analysis), que já é SSRF-safe.
    4. Converte a nota interna (0-100, 100=seguro) para a nota exibida
       ao lead (0-10, 10=mais vulnerável — conforme especificado).
    5. Gera o PDF completo e envia por e-mail (assíncrono, thread).
    6. Responde à tela SOMENTE com nota + categorias por nome + textos
       de marketing — nunca o detalhe técnico explorável.

Proteções aplicadas (resumo):
  - SSRF: analyzer/netsec bloqueiam qualquer alvo que resolva para IP
    privado/reservado, e não seguem redirect sem revalidar.
  - RCE / Command Injection: nenhuma chamada a subprocess/os.system/eval
    em todo o backend.
  - LFI / Path Traversal: nome de arquivo do PDF nunca é montado com
    string bruta do usuário sem sanitização; PDF fica em memória
    (BytesIO), nunca é escrito em disco com nome derivado do input.
  - XSS: toda entrada é validada por regex fechada; toda saída para
    PDF passa por `sanitize_text` (escape XML/HTML).
  - SSTI: sem Jinja2/template dinâmico com conteúdo do usuário como
    fonte de template — só interpolação de variáveis já escapadas.
"""

import logging
import re
import threading

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from analyzer import run_analysis, normalize_domain, is_valid_domain, sanitize_text, score_to_display_10
from netsec import SSRFBlocked
from pdf_report import build_pdf_report
from emailer import send_report_email

app = Flask(__name__)

# Em produção, troque por origins=["https://seusite.com.br"]
CORS(app, origins=["*"])

limiter = Limiter(get_remote_address, app=app, default_limits=["30 per hour"])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("radar-api")

FREE_EMAIL_DOMAINS = {
    "gmail.com", "hotmail.com", "outlook.com", "yahoo.com", "yahoo.com.br",
    "icloud.com", "live.com", "bol.com.br", "uol.com.br", "terra.com.br",
    "hotmail.com.br", "outlook.com.br", "aol.com", "protonmail.com", "msn.com",
    "zipmail.com.br", "ig.com.br", "r7.com", "globo.com",
}

# regex fechadas — tudo que não bate é rejeitado (allowlist, não blocklist)
NAME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ' \-]{2,80}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@([A-Za-z0-9.\-]+\.[A-Za-z]{2,})$")


def is_corporate_email(email: str):
    match = EMAIL_RE.match((email or "").strip().lower())
    if not match:
        return None
    domain_part = match.group(1)
    if domain_part in FREE_EMAIL_DOMAINS:
        return None
    return domain_part


def score_to_display(score_100: int) -> int:
    """Mantido como alias por compatibilidade — a lógica real vive em
    analyzer.score_to_display_10, compartilhada com o PDF."""
    return score_to_display_10(score_100)


def _send_report_async(name, email, domain, full_report):
    try:
        pdf_bytes = build_pdf_report(name=name, domain=domain, report=full_report)
        send_report_email(
            to_email=email, name=name, domain=domain,
            score=full_report["score"], pdf_bytes=pdf_bytes,
        )
        log.info("Relatório enviado para %s (domínio %s)", email, domain)
    except Exception:
        log.exception("Falha ao gerar/enviar PDF para %s", email)


@app.route("/api/analyze", methods=["POST"])
@limiter.limit("5 per hour")  # limite mais rígido nesta rota específica
def analyze():
    data = request.get_json(silent=True) or {}
    name_raw = (data.get("name") or "").strip()
    email_raw = (data.get("email") or "").strip()
    domain_raw = (data.get("domain") or "").strip()

    errors = {}

    if not NAME_RE.match(name_raw):
        errors["name"] = "Informe um nome válido (apenas letras e espaços)."

    corp_domain = is_corporate_email(email_raw)
    if corp_domain is None:
        errors["email"] = "Use um e-mail corporativo válido (provedores gratuitos não são aceitos)."

    domain = normalize_domain(domain_raw)
    if not is_valid_domain(domain):
        errors["domain"] = "Informe um domínio válido, ex: suaempresa.com.br"

    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    name = sanitize_text(name_raw, max_len=80)
    email = email_raw.lower()

    log.info("Novo lead: %s <%s> domínio=%s", name, email, domain)

    try:
        full_report = run_analysis(domain, level="full")
    except SSRFBlocked as exc:
        log.warning("Bloqueado por proteção SSRF: %s", exc)
        return jsonify({"ok": False, "error": "Não foi possível analisar este domínio (alvo inválido)."}), 400
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception:
        log.exception("Falha ao analisar domínio %s", domain)
        return jsonify({"ok": False, "error": "Não foi possível concluir a análise agora."}), 502

    # dispara PDF + e-mail em background — não deixa o lead esperando
    threading.Thread(
        target=_send_report_async, args=(name, email, domain, full_report), daemon=True,
    ).start()

    display_score = score_to_display(full_report["score"])
    public_categories = [
        {"name": c["name"], "state": c["state"]} for c in full_report["categories"]
    ]

    return jsonify({
        "ok": True,
        "domain": domain,
        "display_score": display_score,   # 0-10, 10 = pior
        "risk_label": full_report["risk_label"],
        "categories": public_categories,   # só nome + estado, sem nota numérica exata
        "email_sent_to": email,
    })


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
