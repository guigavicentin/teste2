"""
pdf_report.py
--------------
Gera o PDF detalhado enviado por e-mail (nunca servido ao navegador do lead).

Visual: tema escuro + verde neon, no mesmo espírito do site (fundo quase
preto, acentos verde/vermelho/âmbar, fontes monoespaçadas para dado
técnico) — desenhado via canvas do reportlab (onFirstPage/onLaterPages),
não HTML-to-PDF (menos superfície de risco, ver README).

Nota de segurança: reportlab interpreta uma mini-marcação tipo XML
dentro de `Paragraph` (<b>, <font color=...>). Todo texto vindo do
usuário passa por `analyzer.sanitize_text()` antes de entrar em
qualquer Paragraph — evita injeção de marcação (uma forma de
HTML/SSTI-injection dentro do próprio motor de PDF).
"""

import io
from datetime import datetime, timezone

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.enums import TA_LEFT

from analyzer import sanitize_text, score_to_display_10

# paleta — mesmos tokens do site
BG = colors.HexColor("#05070a")
BG_RAISED = colors.HexColor("#0d1210")
GREEN = colors.HexColor("#2fe871")
GREEN_DIM = colors.HexColor("#1f9a53")
RED = colors.HexColor("#ff4a5e")
AMBER = colors.HexColor("#ffb238")
TEXT = colors.HexColor("#e8f1ec")
MUTED = colors.HexColor("#8a968f")
BORDER = colors.HexColor("#1c2420")

PAGE_W, PAGE_H = A4
HEADER_H = 2.6 * cm
FOOTER_H = 1.4 * cm


def _state_color(state: str):
    return {"Crítico": RED, "Atenção": AMBER, "Adequado": GREEN}.get(state, MUTED)


def _state_bg(state: str):
    return {
        "Crítico": colors.HexColor("#2a1216"),
        "Atenção": colors.HexColor("#2a2212"),
        "Adequado": colors.HexColor("#122a1a"),
    }.get(state, BG_RAISED)


def _risk_color(risk_label: str):
    if "Alto" in risk_label:
        return RED
    if "Médio" in risk_label:
        return AMBER
    return GREEN


def _draw_page_frame(canvas, doc):
    canvas.saveState()
    # fundo
    canvas.setFillColor(BG)
    canvas.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)

    # cabeçalho
    canvas.setFillColor(BG_RAISED)
    canvas.rect(0, PAGE_H - HEADER_H, PAGE_W, HEADER_H, fill=1, stroke=0)
    canvas.setStrokeColor(GREEN_DIM)
    canvas.setLineWidth(1)
    canvas.line(0, PAGE_H - HEADER_H, PAGE_W, PAGE_H - HEADER_H)

    canvas.setFont("Helvetica-Bold", 15)
    canvas.setFillColor(GREEN)
    canvas.drawString(2 * cm, PAGE_H - 1.5 * cm, "WS VICENTIN")
    canvas.setFont("Courier", 8)
    canvas.setFillColor(MUTED)
    canvas.drawString(2 * cm, PAGE_H - 2.05 * cm, "// SEGURANCA OFENSIVA — RELATORIO DE ANALISE DE SUPERFICIE DE ATAQUE")

    # rodapé
    canvas.setStrokeColor(BORDER)
    canvas.line(2 * cm, FOOTER_H, PAGE_W - 2 * cm, FOOTER_H)
    canvas.setFont("Courier", 7)
    canvas.setFillColor(MUTED)
    canvas.drawString(2 * cm, FOOTER_H - 0.5 * cm, f"pagina {doc.page}")
    canvas.drawRightString(PAGE_W - 2 * cm, FOOTER_H - 0.5 * cm, "wa.me/5547992070823")

    canvas.restoreState()


def _styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("TitleWSV", parent=base["Title"], textColor=TEXT,
                                 fontName="Helvetica-Bold", fontSize=18, spaceAfter=4),
        "h2": ParagraphStyle("H2WSV", parent=base["Heading2"], textColor=GREEN,
                              fontName="Helvetica-Bold", fontSize=12, spaceBefore=16, spaceAfter=8),
        "body": ParagraphStyle("BodyWSV", parent=base["BodyText"], textColor=TEXT,
                                alignment=TA_LEFT, fontName="Helvetica", fontSize=9.5, leading=14),
        "mono": ParagraphStyle("MonoWSV", parent=base["BodyText"], textColor=TEXT,
                                fontName="Courier", fontSize=8.5, leading=13),
        "small": ParagraphStyle("SmallWSV", parent=base["BodyText"], textColor=MUTED,
                                 fontName="Helvetica", fontSize=8, leading=12),
    }


def _score_block(styles, score_10: int, risk: str):
    color = _risk_color(risk)
    hex_color = "#" + color.hexval()[2:]
    tbl = Table(
        [[Paragraph(f"<font color='{hex_color}'><b>{score_10}/10</b></font> — "
                    f"<font color='{hex_color}'>{sanitize_text(risk, 40)}</font>",
                    ParagraphStyle("scoreLine", fontName="Helvetica-Bold", fontSize=15,
                                   textColor=TEXT, leading=20))]],
        colWidths=[17 * cm],
    )
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BG_RAISED),
        ("BOX", (0, 0), (-1, -1), 1, color),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 14),
    ]))
    return tbl


def build_pdf_report(*, name: str, domain: str, report: dict) -> bytes:
    safe_name = sanitize_text(name, max_len=80)
    safe_domain = sanitize_text(domain, max_len=253)
    styles = _styles()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        topMargin=HEADER_H + 0.8 * cm, bottomMargin=FOOTER_H + 0.8 * cm,
        leftMargin=2 * cm, rightMargin=2 * cm,
        title=f"Relatorio de Seguranca - {safe_domain}",
    )

    elements = []
    elements.append(Paragraph(f"Domínio analisado: <b><font color='#2fe871'>{safe_domain}</font></b>", styles["body"]))
    elements.append(Paragraph(f"Solicitado por: {safe_name}", styles["small"]))

    generated_human = sanitize_text(report.get("generated_at_human") or "", 40)
    if generated_human:
        elements.append(Paragraph(f"Análise realizada em: {generated_human}", styles["small"]))
    elements.append(Spacer(1, 14))

    # nota — MESMA escala 0-10 exibida no site (10 = pior)
    score_100 = report.get("score", 0)
    score_10 = score_to_display_10(score_100)
    risk = report.get("risk_label", "")
    elements.append(Paragraph("NOTA DE VULNERABILIDADE (mesma escala exibida no site — quanto maior, pior)", styles["h2"]))
    elements.append(_score_block(styles, score_10, risk))
    elements.append(Spacer(1, 18))

    # categorias — escala interna 0-100 (adequação), deixando claro que é OUTRA escala
    elements.append(Paragraph("DETALHAMENTO POR CATEGORIA (nota de adequação 0-100 — quanto maior, melhor)", styles["h2"]))
    cat_rows = [["Categoria", "Adequação", "Situação"]]
    cat_row_states = [None]
    for c in report.get("categories", []):
        cat_rows.append([sanitize_text(c["name"], 60), f"{c['val']}/100", sanitize_text(c["state"], 20)])
        cat_row_states.append(c["state"])

    cat_table = Table(cat_rows, colWidths=[9.5 * cm, 3 * cm, 4.5 * cm])
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), BG_RAISED),
        ("TEXTCOLOR", (0, 0), (-1, 0), GREEN),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Courier"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("TEXTCOLOR", (0, 1), (-1, -1), TEXT),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]
    for i, state in enumerate(cat_row_states):
        if state:
            style_cmds.append(("BACKGROUND", (2, i), (2, i), _state_bg(state)))
            style_cmds.append(("TEXTCOLOR", (2, i), (2, i), _state_color(state)))
    cat_table.setStyle(TableStyle(style_cmds))
    elements.append(cat_table)
    elements.append(Spacer(1, 18))

    # subdomínios
    elements.append(Paragraph(f"SUBDOMÍNIOS ANALISADOS ({report.get('subdomains_scanned', 0)} encontrados)", styles["h2"]))
    sub_rows = [["Subdomínio", "Headers", "WAF", "CDN", "HTTPS", "Risco"]]
    any_reachable = False
    for s in report.get("subdomains", []):
        if not s.get("reachable"):
            continue
        any_reachable = True
        sub_rows.append([
            sanitize_text(s["subdomain"], 55),
            f"{s['headers']['score']}%",
            "Sim" if s["waf"]["detected"] else "Não",
            sanitize_text(s["cdn"] or "—", 18),
            "Sim" if s["https_redirect"] else "Não",
            sanitize_text(s["risk"], 15),
        ])
    if any_reachable:
        sub_table = Table(sub_rows, colWidths=[5.5 * cm, 2 * cm, 2 * cm, 2.5 * cm, 2 * cm, 3 * cm])
        sub_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), BG_RAISED),
            ("TEXTCOLOR", (0, 0), (-1, 0), GREEN),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTNAME", (0, 1), (-1, -1), "Courier"),
            ("TEXTCOLOR", (0, 1), (-1, -1), TEXT),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ]))
        elements.append(sub_table)
    else:
        elements.append(Paragraph("Nenhum subdomínio respondeu durante a análise.", styles["body"]))

    elements.append(Spacer(1, 6))
    elements.append(Paragraph(
        f"Fontes usadas na descoberta de subdomínios: Certificate Transparency (crt.sh + CertSpotter), "
        f"HackerTarget e resolução DNS de uma lista curta de nomes comuns — todas consultas públicas, "
        f"sem interação direta com os servidores do domínio.", styles["small"]))

    # headers ausentes
    missing_lines = []
    for s in report.get("subdomains", []):
        if s.get("reachable") and s["headers"]["missing"]:
            missing = ", ".join(sanitize_text(h, 40) for h in s["headers"]["missing"])
            missing_lines.append(f"<b>{sanitize_text(s['subdomain'], 55)}</b>: faltando {missing}")
    if missing_lines:
        elements.append(Spacer(1, 14))
        elements.append(Paragraph("HEADERS DE SEGURANÇA AUSENTES", styles["h2"]))
        for line in missing_lines:
            elements.append(Paragraph(line, styles["body"]))

    # portas
    risky = report.get("risky_ports_open", [])
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("PORTAS SENSÍVEIS EXPOSTAS PUBLICAMENTE", styles["h2"]))
    if risky:
        for p in risky:
            banner = sanitize_text(p.get("banner") or "sem banner identificado", 100)
            elements.append(Paragraph(
                f"<font color='#ff4a5e'><b>Porta {p['port']}</b></font> "
                f"({sanitize_text(p['service'], 30)}) — {banner}", styles["mono"]))
    else:
        elements.append(Paragraph("Nenhuma porta sensível (21/22/3306/5432) encontrada aberta.", styles["body"]))

    # spoofing de e-mail
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("PROTEÇÃO CONTRA SPOOFING DE E-MAIL", styles["h2"]))
    spoof = report.get("email_spoofing", {})
    elements.append(Paragraph(
        f"SPF (domínio raiz): {'presente' if spoof.get('spf', {}).get('present') else 'ausente'}", styles["mono"]))
    dmarc = spoof.get("dmarc", {})
    dmarc_txt = "ausente"
    if dmarc.get("present"):
        dmarc_txt = f"presente (política: {sanitize_text(dmarc.get('policy') or 'não especificada', 20)})"
    elements.append(Paragraph(f"DMARC: {dmarc_txt}", styles["mono"]))
    elements.append(Paragraph(
        f"DKIM: {'presente' if spoof.get('dkim', {}).get('present') else 'não identificado (seletor comum)'}",
        styles["mono"]))

    elements.append(Spacer(1, 8))
    if dmarc.get("present"):
        sub_policy = dmarc.get("subdomain_policy") or dmarc.get("policy") or "não definida"
        elements.append(Paragraph(
            f"→ <b>Subdomínios sem DMARC próprio herdam automaticamente a política "
            f"\"{sanitize_text(sub_policy, 20)}\"</b> do domínio raiz (tag sp= ou, na ausência dela, "
            f"a mesma política principal — comportamento padrão da RFC 7489). "
            f"Isso cobre a avaliação de DMARC para todos os subdomínios listados acima.", styles["body"]))
    else:
        elements.append(Paragraph(
            "→ Sem DMARC no domínio raiz, não há política de fallback para nenhum subdomínio — "
            "qualquer subdomínio (com ou sem DMARC próprio) fica sem essa camada de proteção.", styles["body"]))
    elements.append(Paragraph(
        "→ <b>Atenção:</b> SPF, diferente do DMARC, não tem herança automática — cada subdomínio que "
        "envia e-mail precisa do próprio registro SPF. Esta análise verificou SPF apenas no domínio raiz; "
        "subdomínios individuais não foram checados nesse quesito.", styles["small"]))

    # TLS
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("CERTIFICADO TLS", styles["h2"]))
    tls_info = report.get("tls_info", {})
    if tls_info.get("checked"):
        elements.append(Paragraph(f"Protocolo negociado: {sanitize_text(tls_info.get('protocol') or '—', 20)}", styles["mono"]))
        elements.append(Paragraph(f"Emissor: {sanitize_text(tls_info.get('issuer') or '—', 60)}", styles["mono"]))
        elements.append(Paragraph(f"Dias até expirar: {tls_info.get('days_to_expiry', '—')}", styles["mono"]))
    else:
        elements.append(Paragraph("Não foi possível validar o certificado TLS.", styles["body"]))

    # DNS / blocklist
    elements.append(Spacer(1, 14))
    elements.append(Paragraph("MATURIDADE DE DNS E REPUTAÇÃO", styles["h2"]))
    hardening = report.get("dns_hardening", {})
    elements.append(Paragraph(f"DNSSEC: {'ativo' if hardening.get('dnssec') else 'não detectado'}", styles["mono"]))
    elements.append(Paragraph(f"CAA: {'configurado' if hardening.get('caa') else 'não configurado'}", styles["mono"]))
    elements.append(Paragraph(f"security.txt: {'presente' if report.get('security_txt') else 'ausente'}", styles["mono"]))
    rep = report.get("blocklist_reputation", {})
    listed = rep.get("ip_listed") or rep.get("domain_listed")
    listed_txt = "SIM — requer atenção" if listed else "não listado"
    elements.append(Paragraph(f"Presença em blocklist (Spamhaus): {listed_txt}", styles["mono"]))

    elements.append(Spacer(1, 20))
    elements.append(Paragraph(
        "Este relatório reflete uma análise automatizada de reconhecimento passivo. Para uma avaliação "
        "aprofundada (incluindo testes manuais de exploração), fale com nosso time para orçamento de "
        "Pentest Web, Análise de Vulnerabilidade ou Monitoramento de Leaks.", styles["small"]))

    doc.build(elements, onFirstPage=_draw_page_frame, onLaterPages=_draw_page_frame)
    return buffer.getvalue()
