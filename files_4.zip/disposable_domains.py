"""
disposable_domains.py
-----------------------
Lista de domínios de e-mail temporário/descartável (temp-mail, 10 minute
mail, mailinator, etc). Fica em arquivo separado de propósito: essa lista
precisa de manutenção periódica (novos serviços aparecem, domínios saem
do ar), então mantê-la isolada facilita atualizar sem tocar na lógica
de validação em `app.py`.

LIMITAÇÃO IMPORTANTE: serviços como temp-mail.org geram domínios novos
com frequência (às vezes dezenas por semana) especificamente para
escapar de blocklists estáticas como esta. Uma lista fixa cobre a
grande maioria do uso casual (as pessoas normalmente usam os serviços
mais conhecidos, não ficam caçando o domínio mais novo), mas não é
garantia de 100%.

Para cobertura mais completa e atualizada automaticamente, dá pra
sincronizar periodicamente com uma lista mantida pela comunidade, por
exemplo:
  https://github.com/disposable/disposable-email-domains
  https://raw.githubusercontent.com/disposable/disposable-email-domains/master/domains.txt
(tem ~3000+ domínios, atualizada com frequência). Ver função
`sync_from_remote()` no final deste arquivo — não é chamada
automaticamente, fica pronta pra usar se/quando quiser ativar.
"""

DISPOSABLE_EMAIL_DOMAINS = {
    # temp-mail e variações
    "temp-mail.org", "tempmail.com", "tempmailo.com", "tempmail.net",
    "tempmail.dev", "temp-mail.io", "tempr.email", "tempinbox.com",
    "tempmailaddress.com", "tmail.ws", "tmpmail.org", "tmpmail.net",
    "tmpeml.com", "tempemail.co", "tempemail.net",

    # 10 minute mail e variações
    "10minutemail.com", "10minutemail.net", "10minemail.com",
    "10minutesmail.com", "20minutemail.com",

    # mailinator e variações
    "mailinator.com", "mailinator.net", "mailinator2.com",
    "sogetthis.com", "mailinater.com", "mailinatior.com",

    # guerrilla mail
    "guerrillamail.com", "guerrillamail.net", "guerrillamail.org",
    "guerrillamail.biz", "guerrillamail.de", "guerrillamailblock.com",
    "sharklasers.com", "grr.la", "pokemail.net", "spam4.me",

    # yopmail
    "yopmail.com", "yopmail.net", "yopmail.fr", "cool.fr.nf",

    # outros bem conhecidos
    "throwawaymail.com", "throwam.com", "dispostable.com",
    "fakeinbox.com", "trashmail.com", "trashmail.net", "trash-mail.com",
    "mytrashmail.com", "getnada.com", "mohmal.com", "moakt.com",
    "inboxkitten.com", "maildrop.cc", "mailnesia.com", "mailcatch.com",
    "harakirimail.com", "meltmail.com", "spamgourmet.com",
    "discard.email", "discardmail.com", "emkei.cz", "jetable.org",
    "fake-mail.net", "mintemail.com", "mailsac.com", "mailsac.io",
    "generator.email", "emailfake.com", "fakemailgenerator.com",
    "mailtemp.info", "spambox.us", "mt2015.com", "burnermail.io",
    "emailondeck.com", "tempail.com", "deadaddress.com",
    "correotemporal.org", "emailtemporario.com.br", "email-temporario.com",
    "e-mail.mx", "nada.email", "byom.de", "anonbox.net",
}


def is_disposable_email_domain(domain: str) -> bool:
    return domain.lower().strip() in DISPOSABLE_EMAIL_DOMAINS


def sync_from_remote(url: str = "https://raw.githubusercontent.com/disposable/disposable-email-domains/master/domains.txt",
                      timeout: int = 10) -> int:
    """OPCIONAL — não é chamado automaticamente. Baixa a lista mantida
    pela comunidade e MESCLA com a lista local (não substitui, só
    adiciona). Retorna quantos domínios novos foram incorporados.

    Se for usar isso em produção, rode via um job agendado (cron/
    systemd timer) 1x por dia, salvando o resultado num arquivo local
    — não faça essa chamada de rede a cada requisição do formulário,
    isso adicionaria latência e uma dependência externa síncrona no
    caminho crítico do usuário."""
    import requests
    resp = requests.get(url, timeout=timeout)
    resp.raise_for_status()
    new_domains = {line.strip().lower() for line in resp.text.splitlines() if line.strip()}
    before = len(DISPOSABLE_EMAIL_DOMAINS)
    DISPOSABLE_EMAIL_DOMAINS.update(new_domains)
    return len(DISPOSABLE_EMAIL_DOMAINS) - before
