"""
app.py — API do Radar de Segurança (WS Vicentin)

Fluxo:
  POST /api/analyze  {name, email, domain}
    1. Valida entrada estritamente (regex fechada em cada campo —
       mitigação de XSS/Header Injection na origem).
    2. Confirma e-mail corporativo (provedor gratuito é rejeitado).
    3. Roda a análise (analyzer.run_analysis), que já é SSRF-safe.
    4. Converte a nota interna (0-100, 100=seguro) para a nota exibida
       ao lead (0-10, 10=mais vulnerável — conforme especificado).
    5. Gera o PDF completo e envia por e-mail (assíncrono, thread).
    6. Responde à tela SOMENTE com nota + categorias por nome + textos
       de marketing — nunca o detalhe técnico explorável.

Proteções aplicadas (resumo):
  - SSRF: analyzer/netsec bloqueiam qualquer alvo que resolva para IP
    privado/reservado, e não seguem redirect sem revalidar.
  - RCE / Command Injection: nenhuma chamada a subprocess/os.system/eval
    em todo o backend.
  - LFI / Path Traversal: nome de arquivo do PDF nunca é montado com
    string bruta do usuário sem sanitização; PDF fica em memória
    (BytesIO), nunca é escrito em disco com nome derivado do input.
  - XSS: toda entrada é validada por regex fechada; toda saída para
    PDF passa por `sanitize_text` (escape XML/HTML).
  - SSTI: sem Jinja2/template dinâmico com conteúdo do usuário como
    fonte de template — só interpolação de variáveis já escapadas.
"""

import logging
import os
import re
import threading

import dns.resolver

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from analyzer import run_analysis, normalize_domain, is_valid_domain, is_blocked_target, sanitize_text, score_to_display_10
from netsec import SSRFBlocked
from pdf_report import build_pdf_report
from emailer import send_report_email

app = Flask(__name__)

# Em produção, troque por origins=["https://seusite.com.br"]
CORS(app, origins=["*"])

limiter = Limiter(get_remote_address, app=app, default_limits=["30 per hour"])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("radar-api")

FREE_EMAIL_DOMAINS = {
    "gmail.com", "hotmail.com", "outlook.com", "yahoo.com", "yahoo.com.br",
    "icloud.com", "live.com", "bol.com.br", "uol.com.br", "terra.com.br",
    "hotmail.com.br", "outlook.com.br", "aol.com", "protonmail.com", "msn.com",
    "zipmail.com.br", "ig.com.br", "r7.com", "globo.com",
}

# mapeamento de caracteres visualmente parecidos (leetspeak), usado só
# pra DETECTAR disfarce de provedor gratuito (ex: "gma1l.com",
# "gmai1.com") — nunca pra "corrigir" o e-mail, só pra rejeitar
_LEET_MAP = str.maketrans({"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b"})


def _leet_normalize(domain: str) -> str:
    return domain.translate(_LEET_MAP)


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            curr[j] = min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + (ca != cb))
        prev = curr
    return prev[-1]


def _looks_like_free_provider(domain_part: str) -> bool:
    """Pega disfarce tipo 'gma1.com', 'gmai1.com', 'hotmai1.com' — troca
    dígito por letra parecida e compara por distância de edição contra
    os provedores gratuitos conhecidos. Threshold=1 é propositalmente
    apertado pra não gerar falso positivo em domínio corporativo real."""
    normalized = _leet_normalize(domain_part)
    for free in FREE_EMAIL_DOMAINS:
        if normalized == free or _levenshtein(normalized, free) <= 1:
            return True
    return False


def _domain_receives_email(domain_part: str) -> bool:
    """Confirma que o domínio do e-mail tem registro MX (ou, na ausência
    dele, ao menos A/AAAA — fallback permitido pela RFC 5321). Sem
    isso, qualquer domínio inventado/nunca registrado pra receber
    e-mail passaria como 'corporativo válido'."""
    for record_type in ("MX", "A"):
        try:
            answers = dns.resolver.resolve(domain_part, record_type, lifetime=4)
            if len(answers) > 0:
                return True
        except Exception:
            continue
    return False


# regex fechadas — tudo que não bate é rejeitado (allowlist, não blocklist)
NAME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ' \-]{2,80}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@([A-Za-z0-9.\-]+\.[A-Za-z]{2,})$")


def validate_corporate_email(email: str):
    """Retorna (domínio, None) se válido, ou (None, motivo) se não.
    Checagens em ordem de custo crescente — falha rápido antes de gastar
    uma consulta DNS."""
    match = EMAIL_RE.match((email or "").strip().lower())
    if not match:
        return None, "Formato de e-mail inválido."

    domain_part = match.group(1)

    if domain_part in FREE_EMAIL_DOMAINS:
        return None, "Provedores de e-mail gratuitos não são aceitos."

    if _looks_like_free_provider(domain_part):
        return None, "Este domínio de e-mail parece um provedor gratuito disfarçado."

    if not _domain_receives_email(domain_part):
        return None, "Este domínio de e-mail não parece receber e-mails (sem registro MX válido)."

    return domain_part, None


def score_to_display(score_100: int) -> int:
    """Mantido como alias por compatibilidade — a lógica real vive em
    analyzer.score_to_display_10, compartilhada com o PDF."""
    return score_to_display_10(score_100)


def _send_report_async(name, email, domain, full_report):
    try:
        pdf_bytes = build_pdf_report(name=name, domain=domain, report=full_report)
        send_report_email(
            to_email=email, name=name, domain=domain,
            score=full_report["score"], pdf_bytes=pdf_bytes,
        )
        log.info("Relatório enviado para %s (domínio %s)", email, domain)
    except Exception:
        log.exception("Falha ao gerar/enviar PDF para %s", email)


@app.route("/api/analyze", methods=["POST"])
@limiter.limit("5 per hour")  # limite mais rígido nesta rota específica
def analyze():
    data = request.get_json(silent=True) or {}
    name_raw = (data.get("name") or "").strip()
    email_raw = (data.get("email") or "").strip()
    domain_raw = (data.get("domain") or "").strip()

    errors = {}

    if not NAME_RE.match(name_raw):
        errors["name"] = "Informe um nome válido (apenas letras e espaços)."

    corp_domain, email_error = validate_corporate_email(email_raw)
    if corp_domain is None:
        errors["email"] = email_error

    domain = normalize_domain(domain_raw)
    if not is_valid_domain(domain):
        errors["domain"] = "Informe um domínio válido, ex: suaempresa.com.br"
    elif is_blocked_target(domain):
        errors["domain"] = "Este domínio não pode ser analisado por esta ferramenta."

    if errors:
        return jsonify({"ok": False, "errors": errors}), 400

    name = sanitize_text(name_raw, max_len=80)
    email = email_raw.lower()

    log.info("Novo lead: %s <%s> domínio=%s", name, email, domain)

    try:
        full_report = run_analysis(domain, level="full")
    except SSRFBlocked as exc:
        log.warning("Bloqueado por proteção SSRF: %s", exc)
        return jsonify({"ok": False, "error": "Não foi possível analisar este domínio (alvo inválido)."}), 400
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception:
        log.exception("Falha ao analisar domínio %s", domain)
        return jsonify({"ok": False, "error": "Não foi possível concluir a análise agora."}), 502

    # dispara PDF + e-mail em background — não deixa o lead esperando
    threading.Thread(
        target=_send_report_async, args=(name, email, domain, full_report), daemon=True,
    ).start()

    display_score = score_to_display(full_report["score"])
    public_categories = [
        {"name": c["name"], "state": c["state"]} for c in full_report["categories"]
    ]

    return jsonify({
        "ok": True,
        "domain": domain,
        "display_score": display_score,   # 0-10, 10 = pior
        "risk_label": full_report["risk_label"],
        "categories": public_categories,   # só nome + estado, sem nota numérica exata
        "email_sent_to": email,
    })


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    app.run(host="0.0.0.0", port=port, debug=False)
